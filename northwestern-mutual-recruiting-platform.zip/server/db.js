const db = require('./config/database');
module.exports = db;

